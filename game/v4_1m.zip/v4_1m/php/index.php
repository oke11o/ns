<?php
// index.php
// Главная страница, редирект на index.html

header("Location: ../index.html");
exit();
?>
